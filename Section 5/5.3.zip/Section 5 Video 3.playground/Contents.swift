import Foundation

class MyClass{
    func myMethod() throws -> String? {
        return nil
    }
    
}

// SWIFT 5

let myObject = MyClass()
let myResult = try? myObject.myMethod()
myResult?.count

