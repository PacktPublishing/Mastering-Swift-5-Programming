//
//  Book.h
//  Section 8 Video 2
//
//  Created by Packt Pub on 13/04/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

#ifndef Book_h
#define Book_h

#include <stdio.h>

typedef struct {
    int pages;
    char * author;
    char * title;
} Book;

void setBookTitle(Book *, char *);
char * getBookTitle(Book);

#endif /* Book_h */
