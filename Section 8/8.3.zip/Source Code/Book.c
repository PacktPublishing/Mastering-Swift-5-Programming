//
//  Book.c
//  Section 8 Video 2
//
//  Created by Packt Pub on 13/04/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

#include "Book.h"
#include <stdlib.h>
#include <string.h>

void setBookTitle(Book * book, char * title) {
    if(book->title) {
        free(book->title);
    }
    book->title = malloc(strlen(title) + 1);
    strcpy(book->title, title);
}

char * getBookTitle(Book book) {
    return book.title;
}
