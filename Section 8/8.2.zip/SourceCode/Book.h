//
//  Book.h
//  Helper Video 2 Section 8
//
//  Created by Packt Pub on 13/04/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Book : NSObject
    @property NSString *title;
    @property NSString *author;
    @property int pages;

@end

NS_ASSUME_NONNULL_END
