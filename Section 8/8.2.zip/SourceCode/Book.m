//
//  Book.m
//  Helper Video 2 Section 8
//
//  Created by Packt Pub on 13/04/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

#import "Book.h"

@implementation Book
@synthesize title, author, pages;


@end
