//
//  ActionViewController.swift
//  Section 2 Video 5
//
//  Created by Packt Pub on 24/01/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

import UIKit

class ActionViewController: UIViewController {

    var action: (()-> ())?

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func performAction(_ sender: Any) {
        action?()
        
    }
    
    deinit {
        print("ActionViewController has gone")
    }
    
}
