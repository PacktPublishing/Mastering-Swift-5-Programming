//
//  ViewController.swift
//  Section 2 Video 5
//
//  Created by Packt Pub on 24/01/2019.
//  Copyright © 2019 Packt Pub. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var changeColorButton: UIButton!
    @IBOutlet weak var dismissButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let actionViewController = segue.destination as? ActionViewController else {
            return
        }
        
        if sender as? UIButton == changeColorButton {
            actionViewController.action = { [weak actionViewController] in
                actionViewController?.view.backgroundColor = UIColor.green
            }
        } else if sender as? UIButton == dismissButton {
            actionViewController.action = { [weak actionViewController] in
                actionViewController?.dismiss(animated: true, completion: nil)
            }
        }
        
    }
}

